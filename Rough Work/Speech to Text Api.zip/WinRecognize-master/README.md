# WinRecognize
Google Cloud Speech API Winform C# example

Parts of code grabbed from Google Cloud Speech API demo (Synchronus) plus various 
NAudio code to seemlessly record / save then transmit to GCS api
