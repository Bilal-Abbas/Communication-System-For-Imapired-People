﻿
namespace DevelopmentWithADot.AspNetSpeechRecognition
{
	public enum SpeechRecognitionMode
	{
		Desktop,
		Server
	}
}