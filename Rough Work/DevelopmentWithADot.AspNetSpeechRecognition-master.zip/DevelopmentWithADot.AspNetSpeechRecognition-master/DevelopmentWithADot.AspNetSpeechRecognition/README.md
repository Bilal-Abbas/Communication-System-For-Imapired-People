﻿From microphone to .WAV with: getUserMedia and Web Audio: http://typedarray.org/from-microphone-to-wav-with-getusermedia-and-web-audio
Microsoft Speech Platform - Software Development Kit (SDK) (Version 11): http://www.microsoft.com/en-us/download/details.aspx?id=27226
Microsoft Speech Platform - Runtime Languages (Version 11): http://www.microsoft.com/en-us/download/details.aspx?id=27224
Microsoft Speech Platform - Runtime (Version 11): http://www.microsoft.com/en-us/download/details.aspx?id=27225
http://typedarray.org/from-microphone-to-wav-with-getusermedia-and-web-audio/