﻿using System.Web.UI;

namespace DevelopmentWithADot.AspNetSpeechRecognition.Test
{
	public partial class Default : Page
	{
		protected void OnSpeechRecognized(object sender, SpeechRecognizedEventArgs e)
		{
		}
	}
}